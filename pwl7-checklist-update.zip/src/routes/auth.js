const express = require("express");
const bcrypt = require("bcryptjs");
const { db } = require("../db");
const { requireAuth, issueSession, clearSession, bumpTokenVersion } = require("../auth-middleware");
const { loadFamilyState } = require("../family-state");
const { rateLimit, byIp, byIpAndEmail, byUserId } = require("../rate-limit");
const { sendEmail } = require("../email");
const { createToken, consumeToken } = require("../auth-tokens");

const router = express.Router();

// Used to build the links inside verification/reset emails. Same variable
// Google/Facebook login already relies on (see .env.example) — defaults to
// local dev, must be set to the real deployed URL in production or the
// emailed links point at localhost.
const APP_BASE_URL = (process.env.APP_BASE_URL || "http://localhost:3000").replace(/\/$/, "");

const ONE_HOUR_MS = 60 * 60 * 1000;
const ONE_DAY_MS = 24 * ONE_HOUR_MS;

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function sendVerificationEmail(userId, email) {
  const token = createToken(userId, "verify_email", ONE_DAY_MS);
  const link = `${APP_BASE_URL}/api/auth/verify-email?token=${encodeURIComponent(token)}`;
  // Fire-and-forget — sendEmail() never throws (it catches its own errors
  // and logs them), and signup/login should never hang or fail just
  // because an email provider is slow or unconfigured.
  sendEmail({
    to: email,
    subject: "Verify your email — Parents with Love",
    text: `Welcome! Please confirm this is your email address:\n\n${link}\n\nThis link expires in 24 hours. If you didn't create this account, you can ignore this email.`,
    html: `<p>Welcome! Please confirm this is your email address:</p><p><a href="${link}">Verify my email</a></p><p>This link expires in 24 hours. If you didn't create this account, you can ignore this email.</p>`
  });
}

// Login/signup rate limiting: a per-IP limit blunts scripted abuse from one
// source in general, and a tighter per-IP+email limit specifically slows
// credential-stuffing/brute-force against one parent account (which holds
// real facts about real kids) without locking out everyone behind a shared
// IP (e.g. a school or office network) just because of one bad actor.
const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 12,
  keyFn: byIp,
  message: "Too many accounts created from this connection recently. Please try again later."
});

const loginIpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  keyFn: byIp,
  message: "Too many login attempts from this connection. Please try again in a few minutes."
});

const loginEmailLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  keyFn: byIpAndEmail,
  message: "Too many failed attempts for this account. Please wait a few minutes and try again."
});

router.post("/signup", signupLimiter, async (req, res) => {
  const email = normalizeEmail(req.body && req.body.email);
  const password = (req.body && req.body.password) || "";

  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Please enter a valid email address." });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    return res.status(409).json({ error: "An account with that email already exists. Try logging in instead." });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const result = db
    .prepare("INSERT INTO users (email, password_hash, email_verified) VALUES (?, ?, 0)")
    .run(email, passwordHash);
  db.prepare("INSERT INTO family_notes (user_id) VALUES (?)").run(result.lastInsertRowid);

  sendVerificationEmail(result.lastInsertRowid, email);

  issueSession(res, result.lastInsertRowid);
  res.json({ ok: true, email });
});

router.post("/login", loginIpLimiter, loginEmailLimiter, async (req, res) => {
  const email = normalizeEmail(req.body && req.body.email);
  const password = (req.body && req.body.password) || "";

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !user.password_hash) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }

  if (user.suspended) {
    return res.status(403).json({ error: "This account has been suspended." });
  }

  issueSession(res, user.id);
  res.json({ ok: true, email: user.email });
});

router.post("/logout", (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

router.get("/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT id, email, password_hash, email_verified FROM users WHERE id = ?").get(req.userId);
  if (!user) {
    clearSession(res);
    return res.status(401).json({ error: "Account no longer exists." });
  }

  const familyState = loadFamilyState(req.userId);

  res.json({
    email: user.email,
    hasPassword: Boolean(user.password_hash),
    emailVerified: Boolean(user.email_verified),
    children: familyState.children,
    topics_discussed: familyState.topics_discussed,
    notes: familyState.notes,
    last_conversation_at: familyState.last_conversation_at
  });
});

// Re-sends the "verify your email" link — used by the banner shown to a
// logged-in parent whose address isn't confirmed yet (see public/app.js).
// Verification is deliberately a nudge, not a hard gate: chat/memory work
// fully either way, since blocking a brand-new signup on email delivery
// would strand them the moment RESEND_API_KEY isn't configured (see
// src/email.js's demo-mode fallback).
const resendVerificationLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 3,
  keyFn: byUserId,
  message: "Please wait a few minutes before requesting another verification email."
});

router.post("/auth/resend-verification", requireAuth, resendVerificationLimiter, (req, res) => {
  const user = db.prepare("SELECT id, email, email_verified FROM users WHERE id = ?").get(req.userId);
  if (!user) {
    clearSession(res);
    return res.status(401).json({ error: "Account no longer exists." });
  }
  if (user.email_verified) {
    return res.json({ ok: true, alreadyVerified: true });
  }

  sendVerificationEmail(user.id, user.email);
  res.json({ ok: true });
});

// Clicked from the emailed link — a plain GET since it's just following a
// link, not a fetch call. Redirects back to the app with a query flag
// (mirroring the existing ?authError= pattern for social login) so the
// frontend can show a toast either way without needing its own page.
router.get("/auth/verify-email", (req, res) => {
  const userId = consumeToken(req.query && req.query.token, "verify_email");
  if (userId) {
    db.prepare("UPDATE users SET email_verified = 1 WHERE id = ?").run(userId);
    return res.redirect(`${APP_BASE_URL}/?emailVerified=1`);
  }
  res.redirect(`${APP_BASE_URL}/?emailVerified=0`);
});

// Rate-limited the same way login is: per-IP generally, and a tighter
// per-IP+email limit so someone can't use this to spam one parent's inbox.
const forgotPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  keyFn: byIpAndEmail,
  message: "Too many reset requests for that email. Please wait a few minutes and try again."
});

router.post("/auth/forgot-password", forgotPasswordLimiter, (req, res) => {
  const email = normalizeEmail(req.body && req.body.email);
  // Always the same response whether or not an account exists for this
  // email — telling the truth either way would let someone check which
  // email addresses have accounts here just by trying them.
  const genericResponse = { ok: true, message: "If an account exists for that email, we've sent a link to reset the password." };

  if (email && email.includes("@")) {
    const user = db.prepare("SELECT id, email, password_hash FROM users WHERE email = ?").get(email);
    // Social-only accounts (no password_hash) have no password to reset —
    // silently skip sending anything rather than offering to "reset" a
    // password that was never set, which would just confuse a Google/
    // Facebook user. The response looks identical either way.
    if (user && user.password_hash) {
      const token = createToken(user.id, "reset_password", ONE_HOUR_MS);
      const link = `${APP_BASE_URL}/?resetToken=${encodeURIComponent(token)}`;
      sendEmail({
        to: user.email,
        subject: "Reset your password — Parents with Love",
        text: `Someone (hopefully you) asked to reset the password on this account. This link expires in 1 hour and works once:\n\n${link}\n\nIf you didn't request this, you can safely ignore this email — your password hasn't changed.`,
        html: `<p>Someone (hopefully you) asked to reset the password on this account.</p><p><a href="${link}">Reset my password</a></p><p>This link expires in 1 hour and works once. If you didn't request this, you can safely ignore this email — your password hasn't changed.</p>`
      });
    }
  }

  res.json(genericResponse);
});

router.post("/auth/reset-password", async (req, res) => {
  const token = (req.body && req.body.token) || "";
  const newPassword = (req.body && req.body.newPassword) || "";

  if (newPassword.length < 8) {
    return res.status(400).json({ error: "New password must be at least 8 characters." });
  }

  const userId = consumeToken(token, "reset_password");
  if (!userId) {
    return res.status(400).json({ error: "That reset link is invalid or has expired. Please request a new one." });
  }

  const newHash = await bcrypt.hash(newPassword, 10);
  db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(newHash, userId);
  // Whoever asked for this reset just proved control of the inbox, not of
  // any device that was already logged in — invalidate every existing
  // session on the account, the same as a normal in-app password change.
  bumpTokenVersion(userId);

  res.json({ ok: true });
});

module.exports = router;
