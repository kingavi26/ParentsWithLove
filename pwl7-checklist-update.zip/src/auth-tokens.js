// Single-use, expiring tokens for email verification and password reset
// links (see the auth_tokens table in src/db.js). Only a SHA-256 hash of
// each token is ever persisted — the same principle as password hashing —
// so reading the database can't hand someone a working link.
const crypto = require("crypto");
const { db } = require("./db");

const TOKEN_BYTES = 32;

function hashToken(token) {
  return crypto.createHash("sha256").update(String(token)).digest("hex");
}

// Creates a new token for the given purpose ("verify_email" | "reset_password"),
// first invalidating any earlier unused token of that same purpose for this
// user — so only the most recently requested link ever works, and an old
// "forgot password" email from an hour ago can't be replayed after a newer
// one was sent.
function createToken(userId, purpose, ttlMs) {
  db.prepare("DELETE FROM auth_tokens WHERE user_id = ? AND purpose = ? AND used_at IS NULL").run(userId, purpose);

  const token = crypto.randomBytes(TOKEN_BYTES).toString("hex");
  const expiresAt = new Date(Date.now() + ttlMs).toISOString();
  db.prepare(
    "INSERT INTO auth_tokens (user_id, purpose, token_hash, expires_at) VALUES (?, ?, ?, ?)"
  ).run(userId, purpose, hashToken(token), expiresAt);

  return token;
}

// Looks up a token for the given purpose and, if it's valid (exists, unused,
// unexpired), marks it used and returns the user id it belongs to. Returns
// null for a missing/reused/expired token without revealing which.
function consumeToken(token, purpose) {
  if (!token) return null;

  const row = db.prepare("SELECT * FROM auth_tokens WHERE token_hash = ? AND purpose = ?").get(hashToken(token), purpose);
  if (!row) return null;
  if (row.used_at) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) return null;

  db.prepare("UPDATE auth_tokens SET used_at = datetime('now') WHERE id = ?").run(row.id);
  return row.user_id;
}

module.exports = { createToken, consumeToken };
