// Minimal transactional email via Resend's plain REST API (no SDK needed —
// just fetch, which Node 20 provides globally, so this adds zero new npm
// dependencies).
//
// With no RESEND_API_KEY set, sendEmail() logs the would-be email to the
// console instead of sending it — the exact same "demo mode" pattern
// OPENAI_API_KEY already uses elsewhere in this app (see .env.example).
// That means password reset and email verification both work end-to-end
// right away (the real link is right there in the server log to copy/paste)
// before you've set up a real email provider, and nothing ever throws or
// blocks a request just because email isn't configured yet.
//
// To send real email: sign up at https://resend.com (free tier covers this
// app's volume many times over), create an API key, and set RESEND_API_KEY
// in the server's environment. EMAIL_FROM is optional — Resend's own
// onboarding@resend.dev sender works out of the box before you verify your
// own domain with them.
const RESEND_API_KEY = process.env.RESEND_API_KEY || "";
const EMAIL_FROM = process.env.EMAIL_FROM || "Parents with Love <onboarding@resend.dev>";
const isEmailConfigured = Boolean(RESEND_API_KEY);

async function sendEmail({ to, subject, html, text }) {
  if (!isEmailConfigured) {
    console.log(
      `[pwl7] EMAIL not sent (no RESEND_API_KEY configured) — to=${to} subject="${subject}"\n${text || html}`
    );
    return { ok: true, simulated: true };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ from: EMAIL_FROM, to, subject, html, text })
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      console.error(`[pwl7] Resend send failed (${res.status}): ${body}`);
      return { ok: false };
    }
    return { ok: true };
  } catch (err) {
    console.error("[pwl7] Resend send threw:", err && err.message);
    return { ok: false };
  }
}

module.exports = { sendEmail, isEmailConfigured };
