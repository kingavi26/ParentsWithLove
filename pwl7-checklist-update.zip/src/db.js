const Database = require("better-sqlite3");
const path = require("path");

// A single SQLite file holds everything. Fine for one small site's worth
// of users; if this ever needs to scale past that, swap this file for a
// Postgres client and keep the same function signatures below.
//
// DB_PATH lets a host with a persistent disk (e.g. Render) point this at a
// mounted volume so the file survives redeploys. Unset it and nothing
// changes from before — same relative data.sqlite next to the app.
const dbPath = process.env.DB_PATH || path.join(__dirname, "..", "data.sqlite");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT,
      google_id TEXT,
      facebook_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- One row per child we've learned about, per family.
    CREATE TABLE IF NOT EXISTS children (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      name TEXT,
      age INTEGER,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- One row per family: everything else we remember, as small
    -- structured lists rather than a full transcript.
    CREATE TABLE IF NOT EXISTS family_notes (
      user_id INTEGER PRIMARY KEY REFERENCES users(id),
      topics_discussed TEXT NOT NULL DEFAULT '[]',
      notes TEXT NOT NULL DEFAULT '[]',
      last_message_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- One row per "rate this session" click: the assistant's self-critique
    -- of its own replies in that conversation, judged against both the
    -- pwl7 framework and general child development research. Used to spot
    -- patterns worth folding back into BASE_RULES in src/prompt.js.
    CREATE TABLE IF NOT EXISTS session_reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      overall_score REAL,
      dimension_scores TEXT NOT NULL DEFAULT '{}',
      strengths TEXT NOT NULL DEFAULT '[]',
      concerns TEXT NOT NULL DEFAULT '[]',
      missed_opportunities TEXT NOT NULL DEFAULT '[]',
      suggested_prompt_changes TEXT NOT NULL DEFAULT '[]',
      message_count INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- Small key/value store for admin-editable app config that needs to
    -- survive redeploys. Right now this holds one key, "base_rules" — an
    -- admin-set override of the BASE_RULES framework text in src/prompt.js
    -- — but the shape is generic so future admin-editable settings can
    -- reuse it without another migration.
    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- One-time-use tokens for email verification and password reset links
    -- (see src/auth-tokens.js). Only the SHA-256 hash of the token is ever
    -- stored, the same way passwords are only ever stored hashed — so a
    -- database read alone can't be used to forge a working link.
    CREATE TABLE IF NOT EXISTS auth_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      purpose TEXT NOT NULL,
      token_hash TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_auth_tokens_lookup ON auth_tokens(token_hash, purpose);
  `);

  // Migration path for a users table created before social login existed
  // (password_hash was NOT NULL and there was no google_id/facebook_id).
  // Matters once a persistent disk is attached; a no-op on the current
  // ephemeral deploy since the table above is always created fresh there.
  const columns = db.prepare("PRAGMA table_info(users)").all().map((c) => c.name);
  if (!columns.includes("google_id")) {
    db.exec("ALTER TABLE users ADD COLUMN google_id TEXT");
  }
  if (!columns.includes("facebook_id")) {
    db.exec("ALTER TABLE users ADD COLUMN facebook_id TEXT");
  }
  // Lets an admin suspend an account (see src/routes/admin.js) without
  // deleting it — blocks both password and social login, and immediately
  // invalidates any session already in progress (see requireAuth).
  if (!columns.includes("suspended")) {
    db.exec("ALTER TABLE users ADD COLUMN suspended INTEGER NOT NULL DEFAULT 0");
  }
  // Bumped whenever a password changes (or a parent explicitly logs out
  // other devices) — requireAuth checks this against the value baked into
  // each session's JWT at issue time, so a stale session stops working
  // immediately instead of staying valid for up to 30 more days. Existing
  // sessions issued before this column existed carry no tokenVersion claim
  // at all, which requireAuth treats as matching (see src/auth-middleware.js)
  // so nobody gets logged out by this migration itself.
  if (!columns.includes("token_version")) {
    db.exec("ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 0");
  }
  // Gates the "verify your email" nudge (soft — see src/routes/auth.js) for
  // new password-based signups. Every account that already existed before
  // this column was added is backfilled to verified=1 here, in the same
  // migration step, so nobody who already had a working account suddenly
  // gets treated as unverified. New rows insert their own explicit value
  // (0 for a fresh password signup, 1 for social login, whose provider has
  // already confirmed the address) rather than relying on this default.
  if (!columns.includes("email_verified")) {
    db.exec("ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0");
    db.exec("UPDATE users SET email_verified = 1");
  }

  // Migration path for a family_notes table created before conversations
  // were timestamped. Left NULL for existing rows (we genuinely don't know
  // when their last message was) rather than backfilling a guess.
  const familyNotesColumns = db.prepare("PRAGMA table_info(family_notes)").all().map((c) => c.name);
  if (!familyNotesColumns.includes("last_message_at")) {
    db.exec("ALTER TABLE family_notes ADD COLUMN last_message_at TEXT");
  }
}

module.exports = { db, initDb };
